For project information and documentation please see

   http://code.google.com/p/jblogbackup/
   
This software is licensed under the Apache License 2.0. 
See APACHE-LICENSE-2.0.txt for details.   