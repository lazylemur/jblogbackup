/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * A buffer that is backed by a file if the amount written
 * exceeds the buffer size.
 * 
 * The buffer can also be forced to be written to the file.
 * 
 * @author lemur
 *
 */
public class FileBackedBuffer extends OutputStream {

	private static final Logger log = LogManager.getLogger(FileBackedBuffer.class);
	
	private byte[] buffer;
	private int bytesWritten = 0;
	private int bufferSize;
	private File overflowFile;
	private FileOutputStream fos;
	private boolean wroteToFile = false;
	
	public FileBackedBuffer(int bufferSize) throws IOException {
		this(bufferSize, File.createTempFile("jbb", null));
	}
	
	public FileBackedBuffer(int bufferSize, File overflowFile) {		
		if (overflowFile == null) {
			throw new IllegalArgumentException("overflow file must not be null");
		}		
		this.bufferSize = bufferSize;
		this.buffer = new byte[bufferSize];
		this.overflowFile = overflowFile;
	}
	

	@Override
	public synchronized void write(int b) throws IOException {

		if (bytesWritten < bufferSize) {
			this.buffer[bytesWritten] = (byte)b;
		} else if (bytesWritten == bufferSize) {
			flushToFile();
			fos.write(b);
		} else {
			// fos must be non null at this point
			fos.write(b);
		}
		
		bytesWritten++;								
	}

	public synchronized byte[] toByteArray() throws IOException {
		if (this.bytesWritten <= this.bufferSize) {
			byte[] dest = new byte[this.bytesWritten];
			System.arraycopy(this.buffer, 0, dest, 0, this.bytesWritten);		
			return dest;
		} else {
			flush();
			FileInputStream fis = new FileInputStream(this.overflowFile);
			byte[] dest = IOUtils.toByteArray(fis);
			fis.close();
			return dest;			
		}
	}
	
	public synchronized InputStream getInputStream() throws IOException {
		if (this.bytesWritten <= this.bufferSize) {			
			return new ByteArrayInputStream(this.buffer, 0, this.bytesWritten);
		} else {
			flush();
			return new FileInputStream(this.overflowFile);
		}
	}
	
	public synchronized int getSize() {
		return this.bytesWritten;
	}
	
	@Override
	public synchronized void flush() throws IOException {
		if (fos != null) {
			fos.flush();
		}
	}
	
	public synchronized void flushToFile() throws IOException {
		if (!wroteToFile) {
			// Open file for writing. Existing files are overwritten. 
			fos = new FileOutputStream(this.overflowFile, false);
			fos.write(this.buffer, 0, this.bytesWritten);
			fos.flush();			
			wroteToFile = true;			
			if (log.isDebugEnabled()) {
				log.debug("Initiated writing to file " + this.overflowFile.getAbsolutePath());
			}
		}
	}
	
	@Override
	public synchronized void close() throws IOException {
		if (fos != null) {
			fos.flush();
			fos.close();
			fos = null;
		}
	}
	
	public boolean deleteFile() throws IOException {
		return this.overflowFile.delete();
	}
	
	public File getFile() {
		return this.overflowFile;
	}
	
	public synchronized boolean wroteToFile() {
		return this.wroteToFile;
	}
	
	public synchronized String getDestinationDescription() {
		if (this.wroteToFile) {
			return this.overflowFile.getAbsolutePath();
		} else {
			return "Internal Buffer";
		}
	}
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {

		FileBackedBuffer sb = new FileBackedBuffer(128, new File("FileBackedBuffer.txt"));
		
		int LEN = 200;
		for (int i=0; i<LEN-1; i++) {			
			sb.write('A');
		}
		sb.write('Z');
		sb.close();
		
		System.out.println(new String(sb.toByteArray()));
		
		sb.deleteFile();

	}
	
}

