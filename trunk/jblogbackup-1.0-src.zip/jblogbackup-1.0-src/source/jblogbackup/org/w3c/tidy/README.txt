
This code is imported from JTidy

	jtidy-04aug2000r7-dev
	
with some slight modification made.

Modification are marked in the code with the 
comment GCS.

See http://jtidy.sourceforge.net/	

