/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.StringWriter;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.WriterAppender;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;

public class ProcessingLogWrapper {

	private StringWriter errorsAndWarnings;
	
	public ProcessingLogWrapper(final String jobId) {
		
		// add memory buffer log4j appender to catch all errors and warnings
		// needed to dump into the log.html
		// We are using an NDC to only capture the warnings and errors from
		// this run of BlogBackup. This is all a bit convoluted but I wanted
		// to re-use log4j instead of rolling my own mini log infrastructure
		// that can be instantiated multiple times.
		
		NDC.push(jobId);		
		errorsAndWarnings = new StringWriter();		
		WriterAppender jobMemoryAppender = new WriterAppender(
				new PatternLayout("<div class=\"log-entry-header\">%d{ABSOLUTE} %5p %c</div><div class=\"log-entry-message\">%m</div>%n"), 
				errorsAndWarnings);
		jobMemoryAppender.setThreshold(Level.WARN);		
		jobMemoryAppender.addFilter(new Filter() {
			// this appender will only accept messages from itself
			@Override
			public int decide(LoggingEvent event) {
				if (jobId.equals(event.getNDC())) {
					return Filter.ACCEPT;
				} else {
					return Filter.DENY;
				}				
			}			
		});		
		Logger.getRootLogger().addAppender(jobMemoryAppender);		
	}
	
	public String getErrorsAndWarnings() {
		String msgs = errorsAndWarnings.getBuffer().toString();
		if (StringUtils.isBlank(msgs)) {
			return "No Errors or Warnings";
		} else {
			return msgs;
		}
	}
}
