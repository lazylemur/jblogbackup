/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;

public class QueuedDownloaderJob {

	// this special QueuedDownloaderJob marks the end of processing
	static final QueuedDownloaderJob DONE = new QueuedDownloaderJob();
	
	private String url;
	private File file;
	private Exception error;
	private HttpResponseHandler[] handlers;
	
	public QueuedDownloaderJob(String url, File file, HttpResponseHandler[] handlers) {
		this.url = url;
		this.file = file;
		this.handlers = handlers;
	}
	
	private QueuedDownloaderJob() { }
	
	public String getUrl() { return url; }
	
	public File getFile() {	return file; }
	
	public HttpResponseHandler[] getHandlers() { return handlers; }
	
	public boolean hasError() {	return error != null; }
	
	public Exception getError() { return error; }
	
	void setError(Exception error) {
		this.error = error;
	}
}
