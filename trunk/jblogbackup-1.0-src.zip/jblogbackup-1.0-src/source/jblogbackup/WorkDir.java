/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class WorkDir {

	private static final Logger log = LogManager.getLogger(WorkDir.class);
	
	public static final String ImagesSubDirectoryName = "images";
	
	private File dir;
	private File imageSubDir;
	private AtomicInteger count = new AtomicInteger(0);
	
	public WorkDir(File workDir, boolean clean) throws IOException {
		
		// make sure work dir exists		
		if (!workDir.exists()) {
			if (workDir.mkdirs()) {
				log.info("Created work directory " + workDir.getAbsolutePath());
			} else {
				throw new IOException("Unable to create directory " + workDir.getAbsolutePath());
			}
		} else {
			if (!workDir.isDirectory()) {
				throw new IOException(workDir.getAbsolutePath() + " is NOT a directory!");			
			}		
		}

		// make sure we can write to it
		if (!workDir.canWrite()) {
			throw new IOException("Work directory " + workDir.getAbsolutePath() + " is not writable!");
		}

		// see if we need to clean the work directory
		if (clean) {
			FileUtils.cleanDirectory(workDir);
			log.info("Cleaned work directory " + workDir.getAbsolutePath());			
		}
				
		// this is our working directory
		this.dir = workDir;
		
		// create images sub directory
		this.imageSubDir = createDirectory(ImagesSubDirectoryName);		
	}
	
	public File getDir() {
		return dir;
	}
	
	private File createFile(File parentDir, String filename) throws IOException {
		
		if (StringUtils.isBlank(filename)) {
			throw new IllegalArgumentException("filename must not be blank or null");
		}
		
		File newFile = new File(parentDir, filename);
		
		if (newFile.createNewFile()) {
			return newFile;
		} else {
			// name already exists so try new name			
			StringBuilder newFilename = new StringBuilder();
			newFilename.append(FilenameUtils.getBaseName(filename));
			newFilename.append("_");
			newFilename.append(count.incrementAndGet());
			newFilename.append(".");
			newFilename.append(FilenameUtils.getExtension(filename));		
			return createFile(parentDir, newFilename.toString());
		}
		
	}
	
	public File createFile(String filename) throws IOException {
		return createFile(this.dir, filename);
	}
		
	public File createImageFile(String filename) throws IOException {
		return createFile(this.imageSubDir, filename);
	}
	
	public File createDirectory(String dirname) throws IOException {
		File subDir = new File(this.dir, dirname);
		if (subDir.exists()) {
			return subDir;
		} else {
			if (subDir.mkdirs()) {
				return subDir;
			} else {
				throw new IOException("Unable to create directory " + subDir.getAbsolutePath());
			}
		}
		
	}
	
}
