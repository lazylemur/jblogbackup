/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.IOException;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * encapsulates commons HTTP client 
 *
 */
public class HttpGet {

	private static final Logger log = LogManager.getLogger(HttpGet.class);	
		
	private boolean forceGc = false;
	
	public HttpGet(boolean forceGc) {
		this.forceGc = forceGc;
	}
	
	/**
	 * 
	 * @param url
	 * @param destFile may be null
	 * @param forceGc
	 * @return
	 * @throws HttpException
	 * @throws IOException
	 */
	public HttpResponse download(String url, File destFile, HttpResponseHandler[] handlers) throws HttpException, IOException {		
			
		// create a http client with exactly 1 http connection
		// we dont need connection pooling here		
		HttpClient httpClient = new HttpClient();
		httpClient.getHttpConnectionManager().getParams().setMaxTotalConnections(1);

		GetMethod getMethod = new GetMethod(url);
	    getMethod.setFollowRedirects(true);  
	    getMethod.getParams().setCookiePolicy(CookiePolicy.IGNORE_COOKIES);        
        if (log.isDebugEnabled()) {
        	log.debug("Downloading URL: " + url);
        }
        
        try {
            // this may throw IOException including SocketException & SocketTimeoutException
            httpClient.executeMethod(getMethod);
            int statusCode = getMethod.getStatusCode(); 
            if (statusCode == HttpStatus.SC_OK) {
            	String contentType = getMethod.getResponseHeader("Content-Type").getValue();
            	HttpResponse response = new HttpResponse(contentType, getMethod.getResponseCharSet(), getMethod.getResponseBodyAsStream(), destFile, handlers);     
                if (log.isDebugEnabled()) {
                	log.debug("Wrote " + response.getBodySize() + " bytes to " + response.getDestinationDescription());
                }
                return response;
            } else if ((statusCode == HttpStatus.SC_MOVED_TEMPORARILY) || (statusCode == HttpStatus.SC_MOVED_PERMANENTLY)) {
                Header locationHeader = getMethod.getResponseHeader("location");
                if (locationHeader != null) {
                	String redirectLocation = locationHeader.getValue();
                    if (log.isDebugEnabled()) {
                    	log.debug("Redirecting to " + redirectLocation);
                    }
                	return download(redirectLocation, destFile, handlers);
                } else {
                    // The response did not provide the new location for the resource.  
                	throw new HttpException("Redirect had no Location header!");                	
                }            	
            } else {
            	throw new HttpException("Unexpected HTTP status code " + statusCode);
            }
        } finally {
            // be sure the connection is released back to the connection manager
            getMethod.releaseConnection();
            // Optionally call the garbage collector here to release any
            // TCP connections immediately. This can be useful if one sees 
            // java.io.FileNotFoundException due to "Too many open files"
            // This may happen on some hosted servers where the max number
            // of open files is very limited e.g. 100.
            // Note: One could achieve the same effect by fooling
            // with the java garbage collection command line parameters 
            // to ensure that short lived objects are cleaned ASAP.
            if (this.forceGc) {
            	System.gc();
            }
        }         
        
	}
		
}
