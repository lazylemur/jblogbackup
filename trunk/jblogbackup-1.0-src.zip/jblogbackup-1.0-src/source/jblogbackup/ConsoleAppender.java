/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;

/**
 * A simple log4j appender that outputs all non error
 * messages to stdout and all error messages to stderr
 */
public class ConsoleAppender extends AppenderSkeleton {

	/**
	 * Constructs an unconfigured appender
	 */
	public ConsoleAppender() {
	}

    /**
     * Creates a configured appender
     *
     * @param layout layout, may not be null.
     */
	public ConsoleAppender(Layout layout) {
		setLayout(layout);
		String header = getLayout().getHeader();
		if (header != null) {
			System.out.print(header);
			System.out.flush();
		}		
	}	
	
	@Override
	protected void append(LoggingEvent event) {		
		switch(event.getLevel().toInt()) {
		case Level.FATAL_INT:
		case Level.ERROR_INT:
			System.err.print(getLayout().format(event));
			System.err.flush();			
			break;
		case Level.WARN_INT:
		case Level.INFO_INT:
		case Level.DEBUG_INT:
		case Level.TRACE_INT:			
			System.out.print(getLayout().format(event));
			System.out.flush();
			break;		
		case Level.OFF_INT:
		}
		
	}

	@Override
	public void close() {
		String footer = getLayout().getFooter();
		if (footer != null) {
			System.out.print(footer);
			System.out.flush();			
		}			
	}

	@Override
	public boolean requiresLayout() {
		// tells log4j to construct this appender with layout
		return true;
	}



}
