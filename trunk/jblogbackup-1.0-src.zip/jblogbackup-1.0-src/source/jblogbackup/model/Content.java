/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup.model;

import jblogbackup.ContentProcessor;

import org.apache.commons.lang.StringEscapeUtils;


public class Content {
			
	public static final String NO_ERRORS_NO_WARNINGS = "No Errors or Warnings";
	
	private String rawContent;
	private String processedContent;
	private String processingMessages = NO_ERRORS_NO_WARNINGS;
	private ContentProcessor contentProcessor;
	
	public Content(ContentProcessor contentProcessor) {
		this.contentProcessor = contentProcessor;
	}

	public String getRawContent() {
		return rawContent;
	}	
	public String getHtmlEscapedRawContent() {
		return StringEscapeUtils.escapeHtml(rawContent);
	}	
	public void setRawContent(String content) {
		this.rawContent = content;
		contentProcessor.process(this);
	}

	public String getProcessedContent() {
		return processedContent;
	}
	public void setProcessedContent(String processedContent) {
		this.processedContent = processedContent;
	}

	public String getProcessingMessages() {
		return processingMessages;
	}
	public String getHtmlEscapedProcessingMessages() {
		return StringEscapeUtils.escapeHtml(processingMessages);
	}
	public void setProcessingMessages(String processingMessages) {
		this.processingMessages = processingMessages;
	}
	public boolean isHasErrorsOrWarnings() {
		return !NO_ERRORS_NO_WARNINGS.equals(processingMessages);
	}
	
}
