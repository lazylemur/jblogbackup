/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup.model;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jblogbackup.Utils;

public class Blog {

	public enum BlogType {
		Blogger,
		WordPress
	};
	
	private String id;
	private String title;
	private String url;
	private BlogType type;
	private Author author;
	private Date lastUpdated;
	private Date backupCreated;
	private List<Post> posts = new ArrayList<Post>();
	private Map<String,Post> idToPostMap= new HashMap<String, Post>();
		
	public Blog() {
		this.backupCreated = new Date();
	}
	
	public Date getBackupCreated() {
		return this.backupCreated;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
		
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * Blog Type eg Blogger, WordPress, etc
	 * @return
	 */
	public BlogType getType() {
		return type;
	}
	public void setType(BlogType type) {
		this.type = type;
	}
	
	public String getUrl() {
		return this.url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public List<Post> getPosts() {
		return posts;
	}
	public void addPost(Post post) {
		this.idToPostMap.put(post.getId(), post);
		this.posts.add(post);
	}
	public Post getPostById(String id) {
		return idToPostMap.get(id);
	}
		
	public String toString() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);		
		pw.print("Title: "); pw.println(this.title);
		pw.print("Id: "); pw.println(this.id);
		pw.print("Last Updated: "); pw.println(Utils.formatDate(lastUpdated));
		pw.print("Author: ");
		if (author == null) {
			pw.println();
		} else {
			pw.print(this.author.getName()); pw.print(" "); pw.println(this.author.getEmail());			
		}		
		pw.print("Number of Posts: "); pw.println(this.posts.size());
		pw.println();
		for (int p=0; p<posts.size(); p++) {
			pw.print(posts.get(p));
			pw.println();			
		}
		return sw.toString();
	}
}
