/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup.blogger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import jblogbackup.BlogBackup;
import jblogbackup.BlogFactory;
import jblogbackup.HttpGet;
import jblogbackup.QueuedDownloader;
import jblogbackup.QueuedDownloaderJob;
import jblogbackup.SimpleNamespaceContext;
import jblogbackup.Utils;
import jblogbackup.WorkDir;
import jblogbackup.model.Author;
import jblogbackup.model.Blog;
import jblogbackup.model.Comment;
import jblogbackup.model.Content;
import jblogbackup.model.Post;


import org.apache.commons.httpclient.HttpException;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class BloggerBlogFactory implements BlogFactory {

	private static final Logger log = LogManager.getLogger(BloggerBlogFactory.class);
	
	private String blogName;
	
	public BloggerBlogFactory(String blogName) {
		this.blogName = blogName;
	}
	
	public Blog createFromRemote(WorkDir workDir, InputStream styleSheetInputStream, HttpGet httpGet, QueuedDownloader imageDownloader) throws HttpException, IOException, XPathExpressionException, ParserConfigurationException, SAXException {
				
		// create styles.css from classpath
		File stylesheetFile = workDir.createFile(BlogBackup.DEFAULT_STYLESHEET);		
		IOUtils.copy(styleSheetInputStream, new FileOutputStream(stylesheetFile));
				
		// create a atom subdirectory to hold our entries and comments xml
		File atomDir = workDir.createDirectory("atom");
		
		// prepare to parse with dom
		DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
		domFactory.setNamespaceAware(true);
		DocumentBuilder domBuilder = domFactory.newDocumentBuilder();

		String baseUrl = "http://" + this.blogName + ".blogspot.com";
		log.info("Blog URL: " + baseUrl);
		
		// get the entries
		File entriesFile = new File(atomDir, "entries.xml");	
		if (!entriesFile.exists()) {
			String entriesUrl = baseUrl + "/feeds/posts/default?alt=atom&max-results=" + Integer.MAX_VALUE;			
			httpGet.download(entriesUrl, entriesFile, null);
		}
		log.info("Downloaded posts.");
		Document entriesDoc = domBuilder.parse(entriesFile);	
		
		// get the entries
		File commentsFile = new File(atomDir, "comments.xml");
		if (!commentsFile.exists()) {
			String commentsUrl = baseUrl + "/feeds/comments/default?alt=atom&max-results=" + Integer.MAX_VALUE;
			httpGet.download(commentsUrl, commentsFile, null);
		}
		log.info("Downloaded comments.");
		Document commentsDoc = domBuilder.parse(commentsFile);
				 		
        // Create a new XPath
        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();        
        SimpleNamespaceContext nsContext = new SimpleNamespaceContext();
        nsContext.addNamespace("atom", "http://www.w3.org/2005/Atom");        
        nsContext.addNamespace("thr", "http://purl.org/syndication/thread/1.0");
        xpath.setNamespaceContext(nsContext);
                
        // XPath exprs used more than once
        XPathExpression xpEntryId = xpath.compile("atom:id");
        XPathExpression xpEntryTitle = xpath.compile("atom:title");
        XPathExpression xpEntryPublished = xpath.compile("atom:published");        
        XPathExpression xpEntryLastUpdated = xpath.compile("atom:updated");
        XPathExpression xpEntryAuthorName = xpath.compile("atom:author/atom:name");
        XPathExpression xpEntryAuthorEmail = xpath.compile("atom:author/atom:email");
        XPathExpression xpEntryAuthorUri = xpath.compile("atom:author/atom:uri");      
        XPathExpression xpEntryContent = xpath.compile("atom:content"); 
        
        // create image downloader
		log.info("Downloading images ...");
		long t0 = System.currentTimeMillis();        
        
        // create Blogger content processor
        BloggerContentProcessor contentProcessor = new BloggerContentProcessor(workDir, imageDownloader);
        
        // Process Entries file
		Blog blog = new Blog();			
		blog.setType(Blog.BlogType.Blogger);
		blog.setUrl(baseUrl);
        
        // Blog Id
        blog.setId(xpath.compile("/atom:feed/atom:id").evaluate(entriesDoc).trim());
        
        // Blog Title
        blog.setTitle(xpath.compile("/atom:feed/atom:title").evaluate(entriesDoc).trim());

        // last updated
        blog.setLastUpdated(Utils.parseRFC3339DateTime(xpath.compile("/atom:feed/atom:updated").evaluate(entriesDoc)));
        
        // Blog Author
        Author blogAuthor = new Author();
        blogAuthor.setName(xpath.compile("/atom:feed/atom:author/atom:name").evaluate(entriesDoc).trim());
        blogAuthor.setEmail(xpath.compile("/atom:feed/atom:author/atom:email").evaluate(entriesDoc).trim());
        blogAuthor.setUri(xpath.compile("/atom:feed/atom:author/atom:uri").evaluate(entriesDoc).trim());
        blog.setAuthor(blogAuthor);
                
        // Blog Entries
        NodeList entries = (NodeList) xpath.compile("/atom:feed/atom:entry").evaluate(entriesDoc, XPathConstants.NODESET);            
		for (int i=0; i<entries.getLength(); i++) {
			Node entryNode = entries.item(i);
			Post post = new Post();
			post.setId(xpEntryId.evaluate(entryNode).trim());
			post.setTitle(xpEntryTitle.evaluate(entryNode).trim());
	        post.setPublished(Utils.parseRFC3339DateTime(xpEntryPublished.evaluate(entryNode)));			
	        post.setLastUpdated(Utils.parseRFC3339DateTime(xpEntryLastUpdated.evaluate(entryNode)));
	        Author postAuthor = new Author();
	        postAuthor.setName(xpEntryAuthorName.evaluate(entryNode).trim());
	        postAuthor.setEmail(xpEntryAuthorEmail.evaluate(entryNode).trim());
	        postAuthor.setUri(xpEntryAuthorUri.evaluate(entryNode).trim());
	        post.setAuthor(postAuthor);
	        Content content = new Content(contentProcessor);
	        content.setRawContent(xpEntryContent.evaluate(entryNode));
	        post.setContent(content);
			blog.addPost(post);
		}
                        
        // Process Comments File
        NodeList comments = (NodeList) xpath.compile("/atom:feed/atom:entry").evaluate(commentsDoc, XPathConstants.NODESET);
        XPathExpression xpEntryInReplyTo = xpath.compile("thr:in-reply-to/@ref");                      
		for (int i=0; i<comments.getLength(); i++) {
			Node commentNode = comments.item(i);
			// create comment node
			Comment comment = new Comment();
			comment.setId(xpEntryId.evaluate(commentNode).trim());
			comment.setPublished(Utils.parseRFC3339DateTime(xpEntryPublished.evaluate(commentNode)));			
	        Author commentAuthor = new Author();
	        commentAuthor.setName(xpEntryAuthorName.evaluate(commentNode).trim());
	        commentAuthor.setEmail(xpEntryAuthorEmail.evaluate(commentNode).trim());
	        commentAuthor.setUri(xpEntryAuthorUri.evaluate(commentNode).trim());
	        comment.setAuthor(commentAuthor);			
	        Content content = new Content(contentProcessor);
	        content.setRawContent(xpEntryContent.evaluate(commentNode));
			comment.setContent(content);
			// get post id to which this belongs
			String postId = xpEntryInReplyTo.evaluate(commentNode);
			Post post = blog.getPostById(postId);
			if (post == null) {
				log.error("Could NOT find the post for comment " + comment.getId() + ". Post id: " + postId);
				log.error(comment.toString());
			} else {
				post.addComment(comment);
			}
		}

		// wait for images to be done downloading
		List<QueuedDownloaderJob> doneList = imageDownloader.waitUntilDone();		
		log.info("Downloaded images in " + (System.currentTimeMillis()-t0)/1000.0 + " secs");
		
		// log any download job errors
		log.debug("IMAGE DOWNLOADS:");
		for (QueuedDownloaderJob job : doneList) {
			if (log.isDebugEnabled()) {
				log.debug(job.getUrl() + "\t\t" + job.getFile().getAbsolutePath());
			}
			if (job.hasError()) {
				log.error("Error downloading image from " + job.getUrl() + " to " + job.getFile().getAbsolutePath() + ". " + 
						job.getError().getClass().getName() + ": " + job.getError().getMessage());				
			}			
		}		
		
		// dump blog to string for debugging
		if (log.isDebugEnabled()) {
			log.debug("BLOG HTML:");			
			log.debug(blog.toString());
		}
			
		return blog;
	}
	

}
