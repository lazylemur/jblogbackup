/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup.blogger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jblogbackup.ContentProcessor;
import jblogbackup.QueuedDownloader;
import jblogbackup.QueuedDownloaderJob;
import jblogbackup.Utils;
import jblogbackup.WorkDir;
import jblogbackup.XmlUtils;
import jblogbackup.model.Content;
import jblogbackup.org.w3c.tidy.Configuration;
import jblogbackup.org.w3c.tidy.Tidy;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class BloggerContentProcessor implements ContentProcessor {

	private static final Logger log = LogManager.getLogger(BloggerContentProcessor.class);

	private static final Pattern BlogSpotComUrl = Pattern.compile("http://.*blogspot\\.com/.*");
	
	private static final String HtmlDocBegin =		
		"<html>" +
		"<head><title></title></head>" + 
		"<body><div>";
	private static final String htmlDocEnd = 
		"</div></body>" +
		"</html>";
	
	private WorkDir workDir;
	private QueuedDownloader imageDownloader;
	
	public BloggerContentProcessor(WorkDir workDir, QueuedDownloader imageDownloader) {
		this.workDir = workDir;
		this.imageDownloader = imageDownloader;
	}
	
	@Override
	public void process(Content content) {

		if (content == null) {
			throw new IllegalArgumentException("Content must be non-null.");
		}
		
		// create a html document
		StringBuilder contentDoc = new StringBuilder();
		contentDoc.append(HtmlDocBegin);
		contentDoc.append(content.getRawContent());
		contentDoc.append(htmlDocEnd);
		
		// process content via Tidy
		Tidy tidy = new Tidy();
		tidy.setXHTML(true); 	// xhtml output 
		tidy.setQuiet(true);
		tidy.setShowWarnings(true);
		tidy.setOnlyErrors(false);
		tidy.setShowErrorSummary(false);		
		tidy.setSmartIndent(true);
		tidy.setCharEncoding(Configuration.UTF8);			
		StringWriter tidyErrorsStr = new StringWriter();
		PrintWriter tidyErrorsPw = new PrintWriter(tidyErrorsStr);
		tidyErrorsPw.println("JTidy Warnings and Errors:");
		tidyErrorsPw.println();
		int tidyErrorsStartLen = tidyErrorsStr.getBuffer().length();
		tidy.setErrout(tidyErrorsPw);
				
		// debug stream can be used to show the tidy'fied html
		ByteArrayOutputStream debugStream = null;
		if (log.isDebugEnabled()) {
			debugStream = new ByteArrayOutputStream();			
		}
		Document doc = tidy.parseDOM(new ByteArrayInputStream(Utils.getBytes(contentDoc.toString())), debugStream); 		
		if (log.isDebugEnabled()) {
			log.debug(Utils.bytesToString(debugStream.toByteArray()));
		}
		
		NodeList imgs = doc.getElementsByTagName("img");   
		for (int i=0; i<imgs.getLength(); i++) {
			Element imgTag = (Element) imgs.item(i);
			org.w3c.dom.Node srcAttr = imgTag.getAttributes().getNamedItem("src"); 
			if (srcAttr != null) {
				String srcUrl = srcAttr.getNodeValue();
				if (StringUtils.isNotBlank(srcUrl)) {					
					String destFilename = Utils.getFilenameFromUrl(srcUrl);					
					if (destFilename != null) {
						// create destination file
						File destFile = null;
						try {
							destFile = workDir.createImageFile(destFilename);
						} catch (IOException ioe) {
							String msg = "Failed to create file " + destFilename + " in working directory " + workDir.getDir().getAbsolutePath();
							log.error(msg);
							imgTag.setAttribute(XmlUtils.CUSTOM_ERROR_ATTRIBUTE, msg);
						}						
						if (destFile != null) {						
							imageDownloader.addJob(new QueuedDownloaderJob(srcUrl, destFile, null));
							// set the src attribute to the new image file location
							srcAttr.setNodeValue(WorkDir.ImagesSubDirectoryName + "/" + destFile.getName());					
							// also try to download the "larger" image that you can 
							// get to via the a tag
							if ("a".equalsIgnoreCase(imgTag.getParentNode().getNodeName())) {
								Element aTag = (Element) imgTag.getParentNode();											
								org.w3c.dom.Node hrefAttr = aTag.getAttributes().getNamedItem("href"); 
								if (hrefAttr != null) {
									String hrefUrl = hrefAttr.getNodeValue();
									if (StringUtils.isNotBlank(hrefUrl)) {
										// only follow hrefs that have the form
										// http://.*blogspot.com/.*
										// eg
										// http://2.bp.blogspot.com/_BzsmyuBXgZo/SRQLHPwbiQI/AAAAAAAAB2w/_qli9tGpau0/s1600-h/b_walks1.jpg
										Matcher urlMatch = BlogSpotComUrl.matcher(hrefUrl);
										if (urlMatch.matches()) {
											if (hrefUrl.toLowerCase().endsWith(destFilename.toLowerCase())) {
												// create 2nd destination file
												File destFile2 = null;
												String destFilename2 = FilenameUtils.getBaseName(destFilename) + "_fullsize." + FilenameUtils.getExtension(destFilename);
												try {
													destFile2 = workDir.createImageFile(destFilename2);
												} catch (IOException ioe) {
													String msg = "Failed to create file " + destFilename2 + " in working directory " + workDir.getDir().getAbsolutePath();
													log.error(msg);
													aTag.setAttribute(XmlUtils.CUSTOM_ERROR_ATTRIBUTE, msg);
												}						
												if (destFile2 != null) {	
												
													imageDownloader.addJob(new QueuedDownloaderJob(
															hrefUrl, 
															destFile2,
															new BloggerClickThruImageHandler[] { new BloggerClickThruImageHandler(imageDownloader) }) );
													// set the src attribute to the new image file location
													hrefAttr.setNodeValue(WorkDir.ImagesSubDirectoryName + "/" + destFile2.getName());					
	
												}												
											}
										}									
									}
								}
							}							
						}
					}					
				}										
			}			
		}		

		// save the tidy errors and warnings and debug log them
		if (tidyErrorsStr.getBuffer().length() > tidyErrorsStartLen) {
			String tidyErrorsAndWarnings = tidyErrorsStr.getBuffer().toString();			
			content.setProcessingMessages(tidyErrorsAndWarnings);
			if (log.isDebugEnabled()) {
				log.debug("\n"+tidyErrorsStr.getBuffer().toString());
			}
		}
		
		// convert the content in the first div tag to text
		NodeList tags = doc.getElementsByTagName("div");
		if (tags.getLength() == 0) {
			throw new IllegalStateException("No div tag found! This should never happen!");			
		}
		
		// now we have the div tag
		org.w3c.dom.Node divTag = tags.item(0);		
		
		// shove the results into the Content object
		content.setProcessedContent(XmlUtils.toString(divTag));		
		
	}

}
