/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup.blogger;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import jblogbackup.HttpResponse;
import jblogbackup.HttpResponseHandler;
import jblogbackup.QueuedDownloader;
import jblogbackup.QueuedDownloaderJob;
import jblogbackup.org.w3c.tidy.Configuration;
import jblogbackup.org.w3c.tidy.Tidy;

public class BloggerClickThruImageHandler implements HttpResponseHandler {

	private static final Logger log = LogManager.getLogger(BloggerClickThruImageHandler.class);	
	
	private QueuedDownloader downloader;
	
	public BloggerClickThruImageHandler(QueuedDownloader downloader) {
		this.downloader = downloader;
	}
	
	@Override
	public void process(HttpResponse httpResponse) {

		if (StringUtils.isNotBlank(httpResponse.getContentType())) {
			
			if (httpResponse.isImage()) {
				
				// do nothing
				
			} else if (httpResponse.isHtml()) {
				
				//
				// This handles downloading Blogger "click through" images
				//

				byte[] body;
				try {
					// get body string and convert to UTF-8 so that tidy
					// can process it safely
					body = httpResponse.getBodyAsString().getBytes("UTF-8");
				} catch (UnsupportedEncodingException uee) {
					// this should never happen in a properly configured JVM
					throw new IllegalStateException("Expected encoding UTF-8 not found!", uee);					
				} catch (IOException ioe) {
					log.error("IO Exception while processing click through image html. ", ioe);
					return;
				}
				
				// process content via Tidy
				Tidy tidy = new Tidy();
				tidy.setXHTML(true); 	// xhtml output 
				tidy.setQuiet(true);
				tidy.setSmartIndent(true);		
				tidy.setCharEncoding(Configuration.UTF8);
				Document doc = tidy.parseDOM(new ByteArrayInputStream(body), null); 			
				NodeList imgs = doc.getElementsByTagName("img");   
				if (imgs.getLength()>0) {
					org.w3c.dom.Node imgTag = imgs.item(0);
					org.w3c.dom.Node srcAttr = imgTag.getAttributes().getNamedItem("src"); 
					if (srcAttr != null) {
						String srcUrl = srcAttr.getNodeValue();
						if (StringUtils.isNotBlank(srcUrl)) {
							this.downloader.addJob(new QueuedDownloaderJob(srcUrl, httpResponse.getBodyFile(), null));
						}						
					}
				}				
				
			} else {
				log.warn("Unexpected Content-Type: " + httpResponse.getContentType());
			}						
		} else {
			log.warn("Empty Content-Type!");			
		}
	}

}
