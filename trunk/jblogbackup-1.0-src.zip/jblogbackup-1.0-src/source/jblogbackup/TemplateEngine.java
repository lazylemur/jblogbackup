/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;

/**
 * Wraps Velocity
 */
public class TemplateEngine {

	private final static Logger log = LogManager.getLogger(TemplateEngine.class);
		
	public static final String TEMPLATE_INDEX = "index.html.vm";
	public static final String TEMPLATE_LOG = "log.html.vm";
    
	public static final String TEMPLATE_NAMES[] = {
		TEMPLATE_INDEX,
		TEMPLATE_LOG
	};
	
	private VelocityEngine velocityEngine;
	private Map<String, Template> templateMap = new HashMap<String, Template>();
	
	public static final TemplateEngine INSTANCE = new TemplateEngine();
		
	private TemplateEngine() {		
		try {
			velocityEngine = new VelocityEngine();				
			velocityEngine.setProperty("resource.loader", "class");		
			velocityEngine.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
			velocityEngine.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");			
			// configure velocity logging
			velocityEngine.setProperty(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM_CLASS, "org.apache.velocity.runtime.log.Log4JLogChute" );
			velocityEngine.setProperty("runtime.log.logsystem.log4j.logger", TemplateEngine.class.getName()+".velocity");
			velocityEngine.init();		
			// check the templates
			for (String templateName : TEMPLATE_NAMES) {				
				String resourcePath = Utils.getClasspathResourcePath(TemplateEngine.class, templateName); 
				if (log.isDebugEnabled()) {
					log.debug("Loading velocity template " + templateName + " from classpath via " + resourcePath);
				}
				Template template = velocityEngine.getTemplate(resourcePath);
				// dummy run the template to ensure there are no syntax errors
				template.merge(new VelocityContext(), new StringWriter());			
				templateMap.put(templateName, template);
				if (log.isDebugEnabled()) {				
					log.debug("Loaded template " + templateName);
				}
			}
			if (log.isDebugEnabled()) {							
				log.debug("Template engine loaded " + templateMap.size() + " templates.");
			}
		} catch (Exception e) {
			// any exception while initializing this class
			// will cause us to throw an unchecked RuntimeException
			// which should cause the app to not start
			throw new RuntimeException("Failed to initialize velocity. ", e);
		}
	}
	
	public void runTemplate(String templateName, VelocityContext context, Writer writer) {
	
		Template template = templateMap.get(templateName);
		if (template == null) {
			// this should NEVER happen 
			throw new IllegalStateException("Unknown template " + templateName);
		}
		
		try {
			template.merge(context, writer);
		} catch (Exception e) {
			// we convert any template run time exceptions to an uncaught exception because
			// the ad server cannot recover from such an error. In general, we EXPECT the templates
			// to work properly. The only way we can get run time errors is due to syntax
			// errors or misconfiguration.
			log.warn("Unexpected error while running template " + templateName, e);
			throw new RuntimeException("Unexpected error while running template " + templateName, e);
		}
		
	}
	
	public String runTemplate(String templateName, VelocityContext context) {
		StringWriter sw = new StringWriter();
		runTemplate(templateName, context, sw);
		return sw.toString();
	}

}