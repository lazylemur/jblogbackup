/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class HttpResponse {

	private static final Logger log = LogManager.getLogger(HttpResponse.class);

	public static final int BUFFER_SIZE = 1024*1024; // 1 MB
	
	private String contentType;
	private String charSet;
	private FileBackedBuffer responseBody;
	
	public HttpResponse(String contentType, String charSet, InputStream responseBodyStream, 
			File destFile, HttpResponseHandler[] handlers) throws IOException {
		
		this.contentType = contentType;		
		this.charSet = charSet;
		this.responseBody = new FileBackedBuffer(BUFFER_SIZE, destFile);
		IOUtils.copy(responseBodyStream, responseBody);	
    	if (destFile != null) {
    		// if a non-null dest file was passed in then 
    		// force the file creation of the underlying buffer
    		responseBody.flushToFile();
    		responseBody.close();    		
    	} else {
    		// its safe to delete the underlying tmp file
    		responseBody.close();
    		responseBody.deleteFile();
    	}
    	
    	// call any handlers
    	if (handlers != null) {
    		for (HttpResponseHandler handler : handlers) {
    			handler.process(this);
    		}
    	}
    	
	}
		
	public String getContentType() {
		return this.contentType;
	}
	
	public int getBodySize() {
		return responseBody.getSize();
	}
	
	public String getDestinationDescription() {
		return responseBody.getDestinationDescription();
	}
	
	public String getBodyAsString() throws IOException {
		byte[] body = responseBody.toByteArray();
		try {
			return new String(body, charSet);
		} catch (UnsupportedEncodingException e) {
			log.warn("Unsupported character encoding: " + charSet + ". Using UTF-8");
			return Utils.bytesToString(body);
		} 
	}

	public File getBodyFile() {
		return responseBody.getFile();
	}
	
	public boolean isImage() {
		if (StringUtils.isBlank(contentType)) {
			return false;
		} else {
			return contentType.toLowerCase().startsWith("image/");
		}
	}

	public boolean isText() {
		if (StringUtils.isBlank(contentType)) {
			return false;
		} else {
			return contentType.toLowerCase().startsWith("text/");
		}
	}
	
	public boolean isHtml() {
		if (StringUtils.isBlank(contentType)) {
			return false;
		} else {
			return contentType.toLowerCase().startsWith("text/html");
		}
	}
	
	public boolean isXml() {
		if (StringUtils.isBlank(contentType)) {
			return false;
		} else {
			// this will catch all this crap
			// 	  text/xml 
			//    application/rss+xml
			//    application/rdf+xml
			//    application/atom+xml
			//    application/xml
			return contentType.toLowerCase().indexOf("xml") > 0;
		}
	}
}
