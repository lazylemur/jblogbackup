/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

import jblogbackup.blogger.BloggerClickThruImageHandler;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

public class QueuedDownloader {
		
	private static final Logger log = LogManager.getLogger(QueuedDownloader.class);		
	
	class Worker extends Thread {
		
		private boolean running = true;
		private HttpGet httpGet;
		private String jobId;		
		
		public Worker(HttpGet httpGet, String jobId, int count) {
			super(QueuedDownloader.class.getSimpleName() + "_" + jobId + "_" + count);
			this.httpGet = httpGet;
			this.jobId = jobId;
		}
		
		public void run() {
			// We are using an NDC to only capture the warnings and errors from
			// this run of BlogBackup. See ProcessingLogWrapper where the log4j
			// memory appender is configured for more details.
			NDC.push(jobId);
			while (running) {
				try {
					QueuedDownloaderJob job = workQueue.take();					
					if (job == QueuedDownloaderJob.DONE) {
						running = false;
						workQueue.put(QueuedDownloaderJob.DONE);
					} else {					
						try {
							httpGet.download(job.getUrl(), job.getFile(), job.getHandlers());
						} catch (Exception e) {
							job.setError(e);
						}
						doneList.add(job);
						
						if (doneList.size()%100 == 0) {
							log.info("Downloaded " + doneList.size() + " of " + numJobs.intValue());
						}
						
					}
				} catch (InterruptedException e) {
				}
			}			
		}
		
	}	
	
	private LinkedBlockingQueue<QueuedDownloaderJob> workQueue = new LinkedBlockingQueue<QueuedDownloaderJob>();	
	private List<QueuedDownloaderJob> doneList = Collections.synchronizedList(new ArrayList<QueuedDownloaderJob>());
	private Worker[] threadPool;
	private final AtomicInteger numJobs = new AtomicInteger(0);
	
	public QueuedDownloader(HttpGet httpGet, String jobId, int numThreads) {
		if (numThreads <= 0) {
			throw new IllegalArgumentException("Number of threads must be > 0. Got " + numThreads);
		}
		// allocate threads
		threadPool = new Worker[numThreads];
		for (int i=0;i<numThreads;i++) {
			threadPool[i] = new Worker(httpGet, jobId, i);
		}
		for (Thread t : threadPool) {
			t.start();
		}		
	}
	
	public void addJob(QueuedDownloaderJob job) {		
		workQueue.add(job);
		numJobs.incrementAndGet();
	}
		
	public List<QueuedDownloaderJob> waitUntilDone() {
		workQueue.add(QueuedDownloaderJob.DONE);		
		for (Thread t : threadPool) {
			try {
				t.join();
			} catch (InterruptedException e) {
			}
		}
		log.info("Downloaded " + doneList.size() + " of " + numJobs.intValue());
		return doneList;
	}
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		String urls[] = {
			"http://4.bp.blogspot.com/_BzsmyuBXgZo/SV1sIyaZREI/AAAAAAAACqM/VYrRcpF_Tvg/s320/crows3.jpg", 
			"http://4.bp.blogspot.com/_BzsmyuBXgZo/SV1sIyaZREI/AAAAAAAACqM/VYrRcpF_Tvg/s1600-h/crows3.jpg", 
			"http://3.bp.blogspot.com/_BzsmyuBXgZo/SV1sLK9T0_I/AAAAAAAACqU/8UzLGzU5OQ0/s320/crows.jpg", 
			"http://3.bp.blogspot.com/_BzsmyuBXgZo/SV1sLK9T0_I/AAAAAAAACqU/8UzLGzU5OQ0/s1600-h/crows.jpg", 
			"http://1.bp.blogspot.com/_BzsmyuBXgZo/SV1sF9kue2I/AAAAAAAACqE/RY3TO-tfwJs/s320/crows2.jpg", 
			"http://1.bp.blogspot.com/_BzsmyuBXgZo/SV1sF9kue2I/AAAAAAAACqE/RY3TO-tfwJs/s1600-h/crows2.jpg", 
			"http://3.bp.blogspot.com/_BzsmyuBXgZo/SV1sAyzQ8WI/AAAAAAAACp8/aE7u1Vbui_A/s320/crows1.jpg", 
			"http://3.bp.blogspot.com/_BzsmyuBXgZo/SV1sAyzQ8WI/AAAAAAAACp8/aE7u1Vbui_A/s1600-h/crows1.jpg", 				
		};

		WorkDir workDir = new WorkDir(new File("QueuedDownloaderTest"), true);
		
		QueuedDownloader downloader = new QueuedDownloader(new HttpGet(false), "testing", 4);

		for (String url : urls) {
			downloader.addJob(new QueuedDownloaderJob(url, workDir.createFile(Utils.getFilenameFromUrl(url)), 
					new BloggerClickThruImageHandler[] { new BloggerClickThruImageHandler(downloader)}));
		}
		List<QueuedDownloaderJob> doneList = downloader.waitUntilDone();
		System.out.println("================================");
		for (QueuedDownloaderJob job : doneList) {
			System.out.println(job.getUrl() + "\t\t" + job.getFile().getAbsolutePath());
		}
		
	}

}
