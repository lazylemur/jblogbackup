/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import jblogbackup.blogger.BloggerBlogFactory;
import jblogbackup.model.Blog;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.xml.sax.SAXException;

public class BlogBackup {
	
	private static final Logger log = LogManager.getLogger(BlogBackup.class);
	
	public static final String DEFAULT_STYLESHEET = "styles.css";
	
	public static String getVersion() {
		// this is read from META-INF/MANIFEST.MF when jblogbackup
		// has been jared up. In dev when jblogbackup is not
		// packaged into a jar file this will return null.
		String version = BlogBackup.class.getPackage().getImplementationVersion();
		if (version == null) {
			version = "dev";
		}
		return version;
	}
	
	public static void backup(BlogBackupParams params) throws IOException, XPathExpressionException, ParserConfigurationException, SAXException {
		
		// verify parameters
		params.verify();
		
		// make sure that the backup dir exists and is writable		
		File backupDir = new File(params.getBackupDir());
		if (!backupDir.exists()) {
			if (!backupDir.mkdirs()) {
				throw new IllegalArgumentException("Unable to create backup directory " + backupDir.getAbsolutePath());
			}
		} else {
			if (!backupDir.isDirectory()) {
				throw new IllegalArgumentException("Backup directory path " + backupDir.getAbsolutePath() + " is NOT a directory!");			
			}			
		}
		if (!backupDir.canWrite()) {
			throw new IllegalArgumentException("Backup directory " + backupDir.getAbsolutePath() + " is not writable! Modify directory permissions.");			
		}

		log.info(BlogBackup.class.getName() + " " + getVersion() + " started on " + Utils.formatDate(new Date()));
		log.info("Blog Name: " + params.getBlogName());
		log.info("Backup Directory: " + backupDir.getAbsolutePath());
		
		// add memory buffer log4j appender to catch all errors and warnings
		// needed to dump into the log.html
		final String jobId = BlogBackup.class.getName() + "_" + Thread.currentThread().hashCode();
		ProcessingLogWrapper processingLog = new ProcessingLogWrapper(jobId);
				
		// create working directory for backup
		WorkDir workDir = new WorkDir(backupDir, params.isCleanBackupDir());
		
		// read stylesheet - for now we only support a default one
		String cssResourcePath = Utils.getClasspathResourcePath(CmdLineTool.class, DEFAULT_STYLESHEET);
		InputStream styleSheetInputStream = CmdLineTool.class.getResourceAsStream(cssResourcePath);
		if (styleSheetInputStream == null) {
			throw new IllegalStateException("Failed to load the default stylesheet " + DEFAULT_STYLESHEET + " from classpath via " + cssResourcePath);
		}
		
		// create a image downloader that can download images in parallel
		HttpGet httpGet = new HttpGet(params.isForceGcToLimitOpenFiles());
        QueuedDownloader imageDownloader = new QueuedDownloader(httpGet, jobId, params.getNumImageDownloadThreads());
		
		// download blog and images and load blog into memory
		Blog blog = new BloggerBlogFactory(params.getBlogName()).createFromRemote(workDir, styleSheetInputStream, httpGet, imageDownloader);
		
		// create our velocity context
		VelocityContext context = new VelocityContext();
		context.put("blog", blog);
		context.put("version", getVersion());
		context.put("log", processingLog);

		// create index.html
		FileWriter indexFw = new FileWriter(workDir.createFile("index.html"));
		TemplateEngine.INSTANCE.runTemplate(TemplateEngine.TEMPLATE_INDEX, context, indexFw);
		indexFw.close();
		
		// create log.html
		FileWriter logFw = new FileWriter(workDir.createFile("log.html"));
		TemplateEngine.INSTANCE.runTemplate(TemplateEngine.TEMPLATE_LOG, context, logFw);
		logFw.close();
		
		// optionally create zip file
		if (params.isCreateZipFile()) {
			File zipFile = new File(params.getZipFilePath());
			Utils.zipDir(zipFile, workDir.getDir(), params.isForceGcToLimitOpenFiles());	
			log.info("Created zip file " + zipFile.getAbsolutePath());
		}
	}

}
