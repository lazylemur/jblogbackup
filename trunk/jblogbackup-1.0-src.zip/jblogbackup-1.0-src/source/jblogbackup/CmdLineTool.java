/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.httpclient.HttpException;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * simple application singleton that wraps application
 * services like the configuration and the database
 */
public class CmdLineTool {
		
	/**
	 * This is the command line interface.
	 * 
	 * @param args
	 * @throws IOException 
	 * @throws HttpException 
	 */
	public static void main(String[] args) throws Exception {
				
		Options options = new Options();
								
		// support various version of help
		String helpItem = "Print this message.";
		// -h --help
		Option help0 = new Option("h", "help", false, helpItem);
		options.addOption(help0);
		// -help		
		Option help1 = new Option("help", false, helpItem);
		options.addOption(help1);
		// -?
		Option help2 = new Option("?", false, helpItem);		
		options.addOption(help2);

		// version flags -v --version
		Option version = new Option("v", "version", false, "Print version information and exit.");
		options.addOption(version);

		// dont read properties files
		Option noProps = new Option(null, "noprops", false, "Do not load any properties from jblogbackup.properties files or Java system properties.");
		options.addOption(noProps);
		
		// print config
		Option printConfig = new Option("p", "printconfig", false, "Print configuration and exit.");
		options.addOption(printConfig);
		
		// blog name (required)
		Option blogName = new Option("n", "blogname", true, "Blog name. REQUIRED.");
		blogName.setArgName("blogname");
		options.addOption(blogName);
		
		// backup directory
		Option backupDir = new Option("b", "backupdir", true, "Path to the backup directory. Will be created if it does not exist. Defaults to blogname/ in the current working directory.");
		backupDir.setArgName("backupdir");
		options.addOption(backupDir);
				
		// append Timestamp to backup directory ?
		Option appendTimestampToBackupDir = new Option(null, "appendtimestamp", false, "If specified, append timestamp to the backup directory in the form \"_ddMMMyy-HHmmss\"");
		options.addOption(appendTimestampToBackupDir);
		
		// clean backup directory ?
		Option cleanBackupDir = new Option("c", "clean", false, "If specified, all files in the backup directory are deleted before the backup starts");
		options.addOption(cleanBackupDir);		
		Option dontCleanBackupDir = new Option(null, "dontclean", false, "If specified, the backup directory will NOT be cleaned");
		options.addOption(dontCleanBackupDir);		

		// create zip file
		Option zip = new Option("z", "zip", true, "Create a zip file of the backup directory. If zipfile path is not specified then backupdir/../backupdir.zip is used.");		
		zip.setArgName("zipfile");
		zip.setOptionalArg(true);
		options.addOption(zip);
		Option dontZip = new Option(null, "dontzip", false, "Do not create a zip file of the backup directory.");
		options.addOption(dontZip);
		
		// number of image download threads
		Option numImageDownloadThreads = new Option(null, "imgthreads", true, "Number of image download threads. It is NOT recommended to exceed 4!");
		numImageDownloadThreads.setArgName("numThreads");
		options.addOption(numImageDownloadThreads);		

		// number of image download threads
		Option forceGcToLimitOpenFiles = new Option(null, "forcegc", false, "Force garbage collection to limit number of open files. Only needed if you see java.io.FileNotFoundException due to \"Too many open files\"");
		options.addOption(forceGcToLimitOpenFiles);				
		
		// log debug
		Option logDebug = new Option(null, "log-debug", false, "Emit debug, info, warning and error messages. Sets Log4J root category level to debug.");
		options.addOption(logDebug);
		
		// log info
		Option logInfo = new Option(null, "log-info", false, "Emit info, warning and error messages. Sets Log4J root category level to info.");
		options.addOption(logInfo);
		
		// log warn
		Option logWarn = new Option(null, "log-warn", false, "Emit warning and error messages. Sets Log4J root category level to warn.");
		options.addOption(logWarn);

		// log error
		Option logError = new Option(null, "log-error", false, "Emit error messages. Sets Log4J root category level to error.");
		options.addOption(logError);

		// create the command line parser
		CommandLineParser parser = new PosixParser();

		// parse the command line arguments
		CommandLine line = null;
		try {
			line = parser.parse( options, args );
		} catch (ParseException pe) {
			printErrorAndExit(pe.getMessage(), options);
		}

		List<Option> parsedOpts = Arrays.asList(line.getOptions());
		
		// set log level
		if (parsedOpts.contains(logDebug)) {
			Logger.getRootLogger().setLevel(Level.DEBUG);
		}		
		if (parsedOpts.contains(logInfo)) {
			Logger.getRootLogger().setLevel(Level.INFO);
		}
		if (parsedOpts.contains(logWarn)) {
			Logger.getRootLogger().setLevel(Level.WARN);
		}
		if (parsedOpts.contains(logError)) {
			Logger.getRootLogger().setLevel(Level.ERROR);
		}
		
		// print help and exit
		if (parsedOpts.contains(help0) || parsedOpts.contains(help1) || parsedOpts.contains(help2)) {
			new HelpFormatter().printHelp(CmdLineTool.class.getName(), options);
			return;
		}		
		
		// print version and exit
		if (parsedOpts.contains(version)) {
			System.out.println(CmdLineTool.class.getName() + " version " + BlogBackup.getVersion());
			return;
		}
				
		BlogBackupParams params = new BlogBackupParams();

		// load defaults from jblogbackup.properties files or
		// java system properties as long as --noprops is not 
		// specified
		if (!parsedOpts.contains(noProps)) {
			params.loadFromProperties();
		}
		
		// process blog name
		if (parsedOpts.contains(blogName)) {
			params.setBlogName(blogName.getValue());
		}
		
		// backup directory
		if (parsedOpts.contains(backupDir)) {
			params.setBackupDir(backupDir.getValue());
		}

		// appendTimestampToWorkDir
		if (parsedOpts.contains(appendTimestampToBackupDir)) {
			params.setAppendTimestampToBackupDir(true);
		}
		
		// cleanBackupDir
		if (parsedOpts.contains(cleanBackupDir)) {
			params.setCleanBackupDir(true);
		}
		if (parsedOpts.contains(dontCleanBackupDir)) {
			params.setCleanBackupDir(false);
		}		
		
		// zip file
		if (parsedOpts.contains(zip)) {			
			params.setCreateZipFile(true);
			if (zip.getValue() != null) {
				params.setZipFilePath(zip.getValue());
			}
		}
		if (parsedOpts.contains(dontZip)) {			
			params.setCreateZipFile(false);
		}

		// num download threads
		if (parsedOpts.contains(numImageDownloadThreads)) {
			try {
				int numThreads = Integer.parseInt(numImageDownloadThreads.getValue());
				params.setNumImageDownloadThreads(numThreads);				
			} catch (NumberFormatException nfe) {
				printErrorAndExit("Failed parsing integer while setting argument --" + numImageDownloadThreads.getLongOpt(), options);
			}
		}
		
		if (parsedOpts.contains(forceGcToLimitOpenFiles)) {
			params.setForceGcToLimitOpenFiles(true);
		}
		
		// verify parameters
		try {
			params.verify();
		} catch (IllegalArgumentException iae) {
			printErrorAndExit(iae.getMessage(), options);			
		}
		
		// print config and exit
		if (parsedOpts.contains(printConfig)) {
			System.out.println(params.toString());
			return;			
		}

		// do backup
		BlogBackup.backup(params);
		
	}
	
	private static void printErrorAndExit(String msg, Options options) {
		System.err.println();
		System.err.println(msg);
		System.err.println();
		PrintWriter pw = new PrintWriter(System.err);
		new HelpFormatter().printHelp(pw, HelpFormatter.DEFAULT_WIDTH, 
				CmdLineTool.class.getName(), null, options, HelpFormatter.DEFAULT_LEFT_PAD, HelpFormatter.DEFAULT_DESC_PAD, null);
		pw.flush();
		System.exit(1);
	}
	
}