/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XmlUtils {
	
	public static final String CUSTOM_ERROR_ATTRIBUTE = "blogbackuperror";
	
    public static void printNodeList(NodeList nodelist, PrintStream ps) {
    	try {
			// Set up an identity transformer to use as serializer.
			Transformer serializer = TransformerFactory.newInstance().newTransformer();
			serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			Node n;
			for (int i = 0; i < nodelist.getLength(); i++) {
				n = nodelist.item(i);
				if (isTextNode(n)) {
					// DOM may have more than one node corresponding to a
					// single XPath text node. Coalesce all contiguous text nodes
					// at this level
					StringBuffer sb = new StringBuffer(n.getNodeValue());
					for (Node nn = n.getNextSibling(); isTextNode(nn); nn = nn.getNextSibling()) {
						sb.append(nn.getNodeValue());
					}
					ps.print(sb);
				} else {
					serializer.transform(new DOMSource(n), new StreamResult(new OutputStreamWriter(ps)));
				}
				ps.println();
			}
    	} catch (Exception e) {
    		e.printStackTrace(ps);
    	}
	}
    
    public static String toString(Node node) {
    	Transformer transformer;
		try {
			transformer = TransformerFactory.newInstance().newTransformer();
		} catch (Exception e) {
			// this should not happen in a normally configured system
			throw new IllegalStateException("Unable to create xml Transformer. ", e);
		}
    	transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    	transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");    	
    	//initialize StreamResult with File object to save to file
    	StreamResult result = new StreamResult(new StringWriter());
    	DOMSource source = new DOMSource(node);
    	String xmlString;
    	try {
			transformer.transform(source, result);
			xmlString = result.getWriter().toString();
		} catch (TransformerException e) {
			xmlString = 
				"<div " + CUSTOM_ERROR_ATTRIBUTE + "=\"Failed converting DOM Node to XML String\" >ERROR: " + 
				e.getMessage() 
				+ "</div>";
		}
    	return xmlString;
    }
    
	
    /** Decide if the node is text, and so must be handled specially */
    public static boolean isTextNode(Node n) {
		if (n == null)
			return false;
		short nodeType = n.getNodeType();
		return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
	}
}
