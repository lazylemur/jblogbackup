/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;
import org.apache.commons.lang.StringUtils;

public class BlogBackupParams {

	//
	// Configuration Properties
	//
	
	public static final String PROP_PREFIX = "jblogbackup.";
	
	public static final String PROP_BLOG_NAME                  = PROP_PREFIX + "blogName";	
	public static final String PROP_BACKUP_DIR                 = PROP_PREFIX + "backupDir";	
	public static final String PROP_WORK_DIR_NAME_APPEND_TS    = PROP_PREFIX + "appendTimestampToBackupDir";
	public static final String PROP_CLEAN_BACKUP_DIR           = PROP_PREFIX + "cleanBackupDir";	
	public static final String PROP_CREATE_ZIP_FILE            = PROP_PREFIX + "createZipFile";	
	public static final String PROP_ZIP_FILE_PATH              = PROP_PREFIX + "zipFilePath";			
	public static final String PROP_NUM_IMAGE_DOWNLOAD_THREADS = PROP_PREFIX + "numImageDownloadThreads";
	public static final String PROP_FORCE_GC_TO_LIMIT_OPEN_FILES = PROP_PREFIX + "forceGcToLimitOpenFiles";
	
	public static final String PROPERTIES_FILENAME = "jblogbackup.properties";
	
	private String blogName;
	private String backupDir;
	private boolean appendTimestampToBackupDir;
	private boolean cleanBackupDir;	
	private boolean createZipFile;
	private String zipFilePath;
	private int numImageDownloadThreads;
	private boolean forceGcToLimitOpenFiles;
		
	public void loadFromProperties() {
		
		// load default values from system properties and properties files
				
		// create our commons config
		CompositeConfiguration config = new CompositeConfiguration();
		// from system properties
		config.addConfiguration(new SystemConfiguration());
		try {
			// from working directory
			File userDir = new File(System.getProperty("user.dir"));
			if (userDir.exists() && userDir.canRead()) {
				config.addConfiguration(new PropertiesConfiguration(new File(userDir, PROPERTIES_FILENAME)));				
			}			
			// from user home directory			
			File userHome = new File(System.getProperty("user.home"));
			if (userHome.exists() && userHome.canRead()) {
				config.addConfiguration(new PropertiesConfiguration(new File(userHome, PROPERTIES_FILENAME)));
			}
			// from classpath
			config.addConfiguration(new PropertiesConfiguration(CmdLineTool.class.getResource("/" + PROPERTIES_FILENAME)));
		} catch (ConfigurationException ce) {
			// this is a fatal error
			throw new IllegalStateException("Failed to initialize the configuration.", ce);
		}

		// now set defaults
		this.blogName = config.getString(PROP_BLOG_NAME);
		this.backupDir = config.getString(PROP_BACKUP_DIR);
		this.appendTimestampToBackupDir = config.getBoolean(PROP_WORK_DIR_NAME_APPEND_TS, false);
		this.createZipFile = config.getBoolean(PROP_CREATE_ZIP_FILE, false);
		this.zipFilePath = config.getString(PROP_ZIP_FILE_PATH);
		this.cleanBackupDir = config.getBoolean(PROP_CLEAN_BACKUP_DIR, false);
		this.numImageDownloadThreads = config.getInt(PROP_NUM_IMAGE_DOWNLOAD_THREADS, 4);
		this.forceGcToLimitOpenFiles = config.getBoolean(PROP_FORCE_GC_TO_LIMIT_OPEN_FILES, false);
		
	}

	public void verify() {		
		if (StringUtils.isBlank(this.blogName)) {
			throw new IllegalArgumentException("Required parameter blogName is missing!");			
		}
		if (StringUtils.isBlank(getBackupDir())) {
			throw new IllegalArgumentException("Required parameter baseDir is missing!");			
		}
	}
		
	public String getBlogName() {
		return blogName;
	}
	public void setBlogName(String blogName) {
		this.blogName = blogName;
	}

	public String getBackupDir() {

		// calc backup dir path
		String path;
		if (StringUtils.isNotBlank(this.backupDir)) {
			path = new File(this.backupDir).getAbsolutePath();
		} else {
			if (StringUtils.isBlank(this.blogName)) {
				throw new IllegalArgumentException("Required parameter blogName is missing!");			
			}
			// default backup dir uses the blog name in the current working directory
			path = new File(this.blogName).getAbsolutePath();
		}

		// optionally append timestamp
		String optionalBackupDirTs = "";
		if (isAppendTimestampToBackupDir()) {
			optionalBackupDirTs += "_" + new SimpleDateFormat("ddMMMyy-HHmmss").format(new Date());
		}
		
		return path + optionalBackupDirTs;
	}
	public void setBackupDir(String backupDir) {
		this.backupDir = backupDir;
	}

	public boolean isAppendTimestampToBackupDir() {
		return appendTimestampToBackupDir;
	}
	public void setAppendTimestampToBackupDir(boolean appendTimestampToBackupDir) {
		this.appendTimestampToBackupDir = appendTimestampToBackupDir;
	}

	public boolean isCreateZipFile() {
		return createZipFile;
	}
	public void setCreateZipFile(boolean createZipFile) {
		this.createZipFile = createZipFile;
	}
	
	public String getZipFilePath() {		
		if (StringUtils.isNotBlank(this.zipFilePath)) {
			return this.zipFilePath;
		} else {
			// defaults to {backupDir}.zip in the parent directory of {backupDir}
			File bd = new File(new File(getBackupDir()).getAbsolutePath());			
			return bd.getParentFile().getAbsoluteFile() + File.separator + bd.getName() + ".zip";			
		}
	}
	public void setZipFilePath(String zipFilePath) {
		this.zipFilePath = zipFilePath;
	}
	
	public boolean isCleanBackupDir() {
		return cleanBackupDir;
	}
	public void setCleanBackupDir(boolean cleanWorkDir) {
		this.cleanBackupDir = cleanWorkDir;
	}

	public int getNumImageDownloadThreads() {
		return numImageDownloadThreads;
	}
	public void setNumImageDownloadThreads(int numImageDownloadThreads) {
		this.numImageDownloadThreads = numImageDownloadThreads;
	}

	public boolean isForceGcToLimitOpenFiles() {
		return forceGcToLimitOpenFiles;
	}
	public void setForceGcToLimitOpenFiles(boolean forceGcToLimitOpenFiles) {
		this.forceGcToLimitOpenFiles = forceGcToLimitOpenFiles;
	}
	
	public String toString() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);		
		pw.println("PARAMETERS");
		pw.print("Blog Name: "); pw.println(getBlogName());
		pw.print("Backup Directory Path: "); pw.println(getBackupDir());
		pw.print("Append Timestamp To Backup Dir: "); pw.println(isAppendTimestampToBackupDir());
		pw.print("Clean Backup Dir: "); pw.println(isCleanBackupDir());		
		pw.print("Create Zip File: "); pw.println(isCreateZipFile());
		pw.print("Zip File Path: "); pw.println(getZipFilePath());
		pw.print("Number of Image Download Threads: "); pw.println(getNumImageDownloadThreads());
		pw.print("Force GC to Limit Open Files: "); pw.println(isForceGcToLimitOpenFiles());
		return sw.toString();
	}
	
}
