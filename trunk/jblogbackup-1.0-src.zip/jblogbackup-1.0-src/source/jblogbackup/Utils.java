/*   
   Copyright 2009 George Stojanoff

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package jblogbackup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Utils {

	private static final Logger log = LogManager.getLogger(QueuedDownloader.class);
	
	public static final String DEFAULT_DATE_TIME_FORMAT = "dd MMM yyyy HH:mm:ss.SSS z";
	
	public static String formatDate(Date date) {
		if (date == null) {
			return "null";
		}
		return new SimpleDateFormat(DEFAULT_DATE_TIME_FORMAT).format(date);		
	}
		
	public static byte[] getBytes(String str) {
		try {
			return str.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// this should never happen in a properly configured JVM
			throw new IllegalStateException("Expected encoding UTF-8 not found!", e);
		}
	}
		
	public static String bytesToString(byte[] bytes) {
		try {
			return new String(bytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// this should never happen in a properly configured JVM
			throw new IllegalStateException("Expected encoding UTF-8 not found!", e);
		}
	}
	
	public static String urlDecode(String str) {
		try {
			return URLDecoder.decode(str, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// this should never happen in a properly configured JVM
			throw new IllegalStateException("Expected encoding UTF-8 not found!", e);
		}
	}
	
	public static String getFilenameFromUrl(String urlStr) {
		URL url = null;
		try {
			url = new URL(urlStr);
			return FilenameUtils.getName(urlDecode(url.getPath()));
		} catch (MalformedURLException mue) {
			log.warn("Failed parsing url: " + urlStr + ".", mue);
			return null;
		}
	}
	
	/**
	 * @param peerClass class that is in the same package as the resource
	 * @param resourceName
	 * @return
	 */
	public static String getClasspathResourcePath(Class<?> peerClass, String resourceName) {
		String packagePath = peerClass.getPackage().getName().replace(".", "/");				
		String resourcePath = "/" + packagePath + "/" + resourceName;
		return resourcePath;
	}
	
	public static void zipDir(File zipFile, File sourceDir, boolean forceGcToLimitOpenFiles) throws IOException {
					
	    // create a ZipOutputStream and zip all files from the source directory 
	    ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
	    zipDir(zos, sourceDir, sourceDir, forceGcToLimitOpenFiles);
	    zos.close();
	    
	}
	
	/**
	 * 
	 * @param zipFile
	 * @param sourceDir
	 * @throws IOException 
	 */
	public static void zipDir(ZipOutputStream zos, File sourceDir, File topSourceDir, boolean forceGcToLimitOpenFiles) throws IOException {

		// various sanity checks
		if (zos == null) {
			throw new IllegalArgumentException("zip output steam must be non-null");			
		}
		if (sourceDir == null) {
			throw new IllegalArgumentException("source directory must be non-null");
		}
		if (!sourceDir.exists()) {
			throw new IllegalArgumentException("source directory " + sourceDir.getAbsolutePath() + " does NOT exist");
		}
		if (!sourceDir.isDirectory()) {
			throw new IllegalArgumentException("source directory " + sourceDir.getAbsolutePath() + " is NOT a directory");
		}
		
        // loop through the source directory and zip files 
        for (File file : sourceDir.listFiles()) { 
        	        	
        	if (file.isDirectory()) {
        		
        		// directory - call recursively
        		zipDir(zos, file, topSourceDir, forceGcToLimitOpenFiles);
        		
        	} else {
        	            
	            // create a new zip entry
        		// we must create paths relative to the top source directory
        		String path = topSourceDir.getName() + file.getPath().substring(topSourceDir.getPath().length());
	            ZipEntry anEntry = new ZipEntry(path); 
	            
	            //place the zip entry in the ZipOutputStream object 
	            zos.putNextEntry(anEntry);
	            
	            //now write the content of the file to the ZipOutputStream        
	            FileInputStream fis = new FileInputStream(file); 
	            IOUtils.copy(fis, zos);
	            fis.close();

	            // Optionally call the garbage collector here to release any
	            // TCP connections immediately. This can be useful if one sees 
	            // java.io.FileNotFoundException due to "Too many open files"
	            // This may happen on some hosted servers where the max number
	            // of open files is very limited e.g. 100.
	            // Note: One could achieve the same effect by fooling
	            // with the java garbage collection command line parameters 
	            // to ensure that short lived objects are cleaned ASAP.	            
	            if (forceGcToLimitOpenFiles) {	            	
	            	System.gc();
	            }
        	}
            
        }
	}
		
	private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
	
	/** XML date/time pattern. */
	public static final Pattern dateTimePattern = Pattern
			.compile("(\\d\\d\\d\\d)\\-(\\d\\d)\\-(\\d\\d)[Tt]"
					+ "(\\d\\d):(\\d\\d):(\\d\\d)(\\.(\\d+))?"
					+ "([Zz]|((\\+|\\-)(\\d\\d):(\\d\\d)))?");

	/**
	 * Code copied from com.google.gdata.data.DateTime.parseDateTime()
	 * version gdata 1.29.0
	 * That code is licensed under Apache 2.0 license.
	 * 
	 * Parses an xs:dateTime string.
	 */
	public static Date parseRFC3339DateTime(String str)
			throws NumberFormatException {

		Matcher m = str == null ? null : dateTimePattern.matcher(str);

		if (str == null || !m.matches()) {
			throw new NumberFormatException("Invalid date/time format.");
		}

		/*
		 * Debugging help: System.out.println("Year: " + m.group(1));
		 * System.out.println("Month: " + m.group(2));
		 * System.out.println("Day: " + m.group(3)); System.out.println("Hour: "
		 * + m.group(4)); System.out.println("Minute: " + m.group(5));
		 * System.out.println("Second: " + m.group(6));
		 * System.out.println("Second Fraction: " + m.group(8));
		 * System.out.println("TZ: " + m.group(9));
		 * System.out.println("TZ Shift: " + m.group(11));
		 * System.out.println("TZ Hour: " + m.group(12));
		 * System.out.println("TZ Minute: " + m.group(13));
		 */

		int tzShift = 0;
		if (m.group(9) == null) {
			// No time zone specified.
		} else if (m.group(9).equalsIgnoreCase("Z")) {
			tzShift = 0;
		} else {
			tzShift = (Integer.valueOf(m.group(12)) * 60)
					+ Integer.valueOf(m.group(13));
			if (m.group(11).equals("-")) {
				tzShift = -tzShift;
			}
		}

		Calendar dateTime = new GregorianCalendar(GMT);

		dateTime.clear();
		dateTime.set(Integer.valueOf(m.group(1)),
				Integer.valueOf(m.group(2)) - 1, Integer.valueOf(m.group(3)),
				Integer.valueOf(m.group(4)), Integer.valueOf(m.group(5)),
				Integer.valueOf(m.group(6)));
		if (m.group(8) != null && m.group(8).length() > 0) {
			final BigDecimal bd = new BigDecimal("0." + m.group(8));
			// we care only for milliseconds, so movePointRight(3)
			dateTime.set(Calendar.MILLISECOND, bd.movePointRight(3).intValue());
		}

		long value = dateTime.getTimeInMillis();
		if (tzShift > 0) {
			value -= tzShift * 60000;
		}

		return new Date(value);
	}
	
}
